import java.util.Set;





    class Professeur extends Personne  {
        private Set<String> specialite;

        public Professeur(String nom, String prenom, int anneeNaissance, String email, Set<String> specialite) {
            super(nom, prenom, anneeNaissance, email);
            this.specialite = specialite;
        }

        interface professeur {
            void enseigner();
            void corrigerExamen();
        }

        @Override
        public void enseigner() {
            System.out.println("Le professeur " + prenom + " " + nom + " enseigne.");
        }

        @Override
        public void corrigerExamen() {
            System.out.println("Le professeur " + prenom + " " + nom + " corrige un examen.");
        }

        @Override
        public void sInscrire() {

        }

        @Override
        public void suivreCours() {

        }

        @Override
        public void passerExamen() {

        }

        @Override
        public String toString() {
            return super.toString() + ", Spécialités: " + specialite;
        }
    }


