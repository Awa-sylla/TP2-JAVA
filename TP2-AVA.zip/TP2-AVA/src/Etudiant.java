public abstract class Etudiant {


    public abstract void sInscrire();

    public abstract void suivreCours();

    public abstract void passerExamen();

    enum Classe {
        L3, M1, M2
    }

    class Professeur extends Personne {
        private String numeroEtudiant;
        private Classe classe;

        public Professeur(String nom, String prenom, int anneeNaissance, String email) {
            super(nom, prenom, anneeNaissance, email);
        }

        interface etudiant {
            void sInscrire();
            void suivreCours();
            void passerExamen();
        }

        @Override
        public void enseigner() {

        }

        @Override
        public void corrigerExamen() {

        }

        @Override
        public void sInscrire() {
            System.out.println("L'étudiant " + prenom + " " + nom + " s'est inscrit.");
        }

        @Override
        public void suivreCours() {
            System.out.println("L'étudiant " + prenom + " " + nom + " suit des cours.");
        }

        @Override
        public void passerExamen() {
            System.out.println("L'étudiant " + prenom + " " + nom + " passe un examen.");
        }

        @Override
        public String toString() {
            return super.toString() + ", Numéro étudiant: " + numeroEtudiant + ", Classe: " + classe;
        }
    }









}
