
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.Set;






abstract class Personne {
    protected String nom;
    protected String prenom;
    protected int anneeNaissance;
    protected String email;

    public Personne(String nom, String prenom, int anneeNaissance, String email) {
        this.nom = nom;
        this.prenom = prenom;
        this.anneeNaissance = anneeNaissance;
        this.email = email;
    }

    public abstract void enseigner();

    public abstract void corrigerExamen();

    public abstract void sInscrire();

    public abstract void suivreCours();

    public abstract void passerExamen();

    @Override
    public String toString() {
        return "Nom: " + nom + ", Prénom: " + prenom + ", Année de Naissance: " + anneeNaissance + ", Email: " + email;
    }
}



