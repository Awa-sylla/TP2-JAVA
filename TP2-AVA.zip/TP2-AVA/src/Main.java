import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        ArrayList<Personne> personnes = new ArrayList<>();
        personnes.add(new Etudiant("awa", "loum", 1998, "awaloum.@email.com", Classe.L3));
        personnes.add(new Etudiant("awa", "sylla", 1997, "awa.sylla@email.com", Classe.M1));
        personnes.add(new Etudiant("Fatou", "diomaye", 1999, "fatou.diomaye.com", Classe.M2));


        Set<String> specialite1 = EnumSet.of("java","php");
        Set<String> specialite2 = EnumSet.of("JAVA", "PHP");
        Set<String> specialite3 = EnumSet.of("JAVA", "PHP");

        personnes.add(new Professeur("awa", "sylla", 1970, "john.doe@email.com", specialite1));
        personnes.add(new Professeur("khady", "Badji", 1965, "jane.smith@email.com", specialite2));
        personnes.add(new Professeur("codou", "Diop", 1980, "carlos.garcia@email.com", specialite3));

        // Affichage des données de chaque objet dans l'ArrayList
        for (Personne personne : personnes) {
            System.out.println(personne.toString());
        }
    }
}